const products = [
  { name: "Органайзер Loft Box", market: "WB", group: "home", sales: 182, revenue: 1248000, profit: 334000, costs: 321000, margin: 26.8, status: "Здоровый рост" },
  { name: "Сыворотка Glow C", market: "Ozon", group: "beauty", sales: 96, revenue: 792000, profit: 162000, costs: 244000, margin: 20.5, status: "Контроль ДРР" },
  { name: "Набор полотенец Soft", market: "WB", group: "home", sales: 134, revenue: 651000, profit: 121000, costs: 173000, margin: 18.6, status: "Проверить логистику" },
  { name: "Детский термостакан", market: "Ozon", group: "kids", sales: 77, revenue: 438000, profit: 103000, costs: 112000, margin: 23.5, status: "Здоровый рост" },
  { name: "Массажная щетка", market: "WB", group: "beauty", sales: 62, revenue: 302000, profit: 31000, costs: 119000, margin: 10.3, status: "Низкая маржа" }
];

const chartSeries = [
  { revenue: 44, profit: 18 },
  { revenue: 52, profit: 22 },
  { revenue: 49, profit: 19 },
  { revenue: 63, profit: 27 },
  { revenue: 58, profit: 24 },
  { revenue: 74, profit: 36 },
  { revenue: 69, profit: 31 },
  { revenue: 82, profit: 38 },
  { revenue: 79, profit: 35 },
  { revenue: 91, profit: 43 },
  { revenue: 86, profit: 41 },
  { revenue: 96, profit: 47 }
];

const alerts = [
  { icon: "₽", title: "Комиссия WB выросла", text: "По двум позициям комиссия выше средней на 4.8 п.п. Проверьте категорию и тариф хранения." },
  { icon: "%", title: "ДРР близок к лимиту", text: "Реклама сыворотки Glow C дает продажи, но съедает 18% выручки за период." },
  { icon: "↻", title: "Остатки на 9 дней", text: "Органайзер Loft Box может уйти в out of stock при текущем темпе продаж." }
];

let expenses = [
  { name: "Закупка", value: 34, amount: 744000 },
  { name: "Логистика", value: 21, amount: 459000 },
  { name: "Комиссии", value: 18, amount: 394000 },
  { name: "Реклама", value: 16, amount: 351000 },
  { name: "Хранение и возвраты", value: 11, amount: 241000 }
];

const ads = [
  { name: "Glow C поиск", market: "Ozon", spend: 142000, sales: 792000, drr: 17.9, status: "Контроль" },
  { name: "Loft Box каталог", market: "WB", spend: 96000, sales: 1248000, drr: 7.7, status: "Ок" },
  { name: "Полотенца ретаргет", market: "WB", spend: 68000, sales: 651000, drr: 10.4, status: "Ок" },
  { name: "Термостакан карточка", market: "Ozon", spend: 45000, sales: 438000, drr: 10.3, status: "Ок" }
];

const stock = [
  { name: "Органайзер Loft Box", market: "WB", quantity: 164, days: 9, supply: "Нужна поставка" },
  { name: "Сыворотка Glow C", market: "Ozon", quantity: 88, days: 18, supply: "Норма" },
  { name: "Набор полотенец Soft", market: "WB", quantity: 57, days: 12, supply: "Планировать" },
  { name: "Детский термостакан", market: "Ozon", quantity: 124, days: 31, supply: "Норма" },
  { name: "Массажная щетка", market: "WB", quantity: 42, days: 20, supply: "Снизить закуп" }
];

const storageKey = "sallerfix.settings";
const operationsStorageKey = "sallerfix.operations";

const defaultOperations = [
  { date: "2026-05-01", market: "WB", category: "Продажа", sku: "Органайзер Loft Box", amount: 1248000, type: "income" },
  { date: "2026-05-01", market: "WB", category: "Комиссия", sku: "Органайзер Loft Box", amount: -143000, type: "expense" },
  { date: "2026-05-02", market: "Ozon", category: "Продажа", sku: "Сыворотка Glow C", amount: 792000, type: "income" },
  { date: "2026-05-02", market: "Ozon", category: "Реклама", sku: "Сыворотка Glow C", amount: -142000, type: "expense" },
  { date: "2026-05-03", market: "WB", category: "Логистика", sku: "Набор полотенец Soft", amount: -81000, type: "expense" },
  { date: "2026-05-04", market: "Ozon", category: "Выплата", sku: "Детский термостакан", amount: 214000, type: "income" }
];

const formatRub = (value) =>
  new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: "RUB",
    maximumFractionDigits: 0
  }).format(value);

const state = {
  period: "30",
  market: "all",
  group: "all",
  operationMarket: "all",
  operationType: "all",
  operationSearch: "",
  activeModal: null,
  costImportRows: 0
};

function getSettings() {
  try {
    return JSON.parse(localStorage.getItem(storageKey)) || {};
  } catch {
    return {};
  }
}

function saveSettingsToStorage(settings) {
  localStorage.setItem(storageKey, JSON.stringify(settings));
}

function getOperations() {
  try {
    return JSON.parse(localStorage.getItem(operationsStorageKey)) || defaultOperations;
  } catch {
    return defaultOperations;
  }
}

function saveOperations(rows) {
  localStorage.setItem(operationsStorageKey, JSON.stringify(rows));
}

function sumOperations(operations, matcher) {
  return operations.filter(matcher).reduce((sum, row) => sum + Math.abs(row.amount), 0);
}

function categoryIncludes(row, words) {
  const category = row.category.toLowerCase();
  return words.some((word) => category.includes(word));
}

function getPnlModel() {
  const operations = getOperations();
  const sales = sumOperations(operations, (row) => row.amount > 0 && categoryIncludes(row, ["продаж", "начислен"]));
  const returns = sumOperations(operations, (row) => row.amount < 0 && categoryIncludes(row, ["возврат", "отмен"]));
  const cogs = sumOperations(operations, (row) => row.amount < 0 && categoryIncludes(row, ["себесто", "закуп"]));
  const commissions = sumOperations(operations, (row) => row.amount < 0 && categoryIncludes(row, ["комисс"]));
  const logistics = sumOperations(operations, (row) => row.amount < 0 && categoryIncludes(row, ["логист", "достав"]));
  const storage = sumOperations(operations, (row) => row.amount < 0 && categoryIncludes(row, ["хран", "прием", "приём"]));
  const adsCost = sumOperations(operations, (row) => row.amount < 0 && categoryIncludes(row, ["реклам", "продвиж"]));
  const knownExpense = returns + cogs + commissions + logistics + storage + adsCost;
  const otherExpenses = Math.max(0, sumOperations(operations, (row) => row.amount < 0) - knownExpense);
  const netRevenue = sales - returns;
  const grossProfit = netRevenue - cogs - commissions - logistics - storage;
  const operatingExpenses = adsCost + otherExpenses;
  const ebitda = grossProfit - operatingExpenses;

  return {
    rows: [
      { label: "Выручка", value: sales, section: "Доходы" },
      { label: "Возвраты и отмены", value: -returns },
      { label: "Чистая выручка", value: netRevenue },
      { label: "Себестоимость", value: -cogs, section: "Переменные расходы" },
      { label: "Комиссии маркетплейсов", value: -commissions },
      { label: "Логистика", value: -logistics },
      { label: "Хранение и приемка", value: -storage },
      { label: "Валовая прибыль", value: grossProfit },
      { label: "Реклама", value: -adsCost, section: "Операционные расходы" },
      { label: "Прочие расходы", value: -otherExpenses },
      { label: "EBITDA", value: ebitda }
    ],
    sales,
    grossProfit,
    operatingExpenses,
    ebitda
  };
}

function getSkuAnalytics() {
  const grouped = new Map();
  getOperations().forEach((row) => {
    const sku = row.sku || "Без SKU";
    const current = grouped.get(sku) || {
      name: sku,
      market: row.market,
      revenue: 0,
      costs: 0,
      profit: 0,
      operations: 0
    };
    if (row.amount > 0) current.revenue += row.amount;
    if (row.amount < 0) current.costs += Math.abs(row.amount);
    current.profit += row.amount;
    current.operations += 1;
    current.market = current.market === row.market ? current.market : "mix";
    grouped.set(sku, current);
  });

  return [...grouped.values()].map((item) => ({
    ...item,
    margin: item.revenue ? Math.round((item.profit / item.revenue) * 1000) / 10 : 0,
    status: item.profit < 0 ? "Убыточный" : item.margin < 15 ? "Низкая маржа" : "Здоровый рост"
  }));
}

const getFilteredProducts = () =>
  products.filter((product) => {
    const matchesMarket = state.market === "all" || product.market === state.market;
    const matchesGroup = state.group === "all" || product.group === state.group;
    return matchesMarket && matchesGroup;
  });

function renderMetrics(rows) {
  const multiplier = Number(state.period) / 30;
  const revenue = rows.reduce((sum, row) => sum + row.revenue, 0) * multiplier;
  const profit = rows.reduce((sum, row) => sum + row.profit, 0) * multiplier;
  const costs = rows.reduce((sum, row) => sum + row.costs, 0) * multiplier;
  const adSpend = costs * 0.22;
  const roi = adSpend ? Math.round((profit / adSpend) * 100) : 0;

  document.querySelector("#revenueMetric").textContent = formatRub(revenue);
  document.querySelector("#profitMetric").textContent = formatRub(profit);
  document.querySelector("#costMetric").textContent = formatRub(costs);
  document.querySelector("#roiMetric").textContent = `${roi}%`;
}

function renderChart() {
  const chart = document.querySelector("#profitChart");
  const periodFactor = Number(state.period) / 30;
  chart.innerHTML = chartSeries
    .map((point) => {
      const revenueHeight = Math.max(8, point.revenue * periodFactor);
      const profitHeight = Math.max(8, point.profit * periodFactor * 1.45);
      return `
        <div class="bar-group">
          <span class="bar revenue" style="height:${revenueHeight}%"></span>
          <span class="bar profit" style="height:${profitHeight}%"></span>
        </div>
      `;
    })
    .join("");
}

function renderProducts(rows) {
  const table = document.querySelector("#productTable");
  table.innerHTML = rows
    .map((product) => {
      const statusClass =
        product.margin < 14 ? "danger" : product.status.includes("Проверить") || product.status.includes("Контроль") ? "warning" : "";
      return `
        <tr>
          <td><strong>${product.name}</strong></td>
          <td>${product.market}</td>
          <td>${product.sales} шт.</td>
          <td>${product.margin}%</td>
          <td><span class="tag ${statusClass}">${product.status}</span></td>
        </tr>
      `;
    })
    .join("");
}

function renderAlerts() {
  const alertList = document.querySelector("#alertList");
  alertList.innerHTML = alerts
    .map(
      (alert) => `
        <div class="alert-item">
          <span class="alert-badge">${alert.icon}</span>
          <div>
            <strong>${alert.title}</strong>
            <span>${alert.text}</span>
          </div>
        </div>
      `
    )
    .join("");
}

function renderExpenses() {
  const total = expenses.reduce((sum, expense) => sum + expense.amount, 0) || 1;
  const markup = expenses
    .map(
      (expense) => `
        <div class="expense-row">
          <div class="expense-top">
            <strong>${expense.name}</strong>
            <span>${formatRub(expense.amount)} · ${Math.round((expense.amount / total) * 100)}%</span>
          </div>
          <div class="expense-bar"><i style="width:${Math.max(4, Math.round((expense.amount / total) * 100))}%"></i></div>
        </div>
      `
    )
    .join("");
  document.querySelector("#expenseStack").innerHTML = markup;
  document.querySelector("#expenseDetailStack").innerHTML = markup;
}

function renderPnl() {
  const model = getPnlModel();
  const table = document.querySelector("#pnlTable");
  table.innerHTML = model.rows
    .map((row) => {
      const section = row.section ? `<tr class="section-row"><td colspan="2">${row.section}</td></tr>` : "";
      const tone = row.value < 0 ? "bad" : row.label.includes("прибыль") || row.label.includes("выручка") || row.label.includes("EBITDA") ? "good" : "";
      return `
        ${section}
        <tr>
          <td>${row.label}</td>
          <td class="${tone}">${formatRub(row.value)}</td>
        </tr>
      `;
    })
    .join("");

  const grossMargin = model.sales ? Math.round((model.grossProfit / model.sales) * 1000) / 10 : 0;
  const ebitdaMargin = model.sales ? Math.round((model.ebitda / model.sales) * 1000) / 10 : 0;
  document.querySelector("#grossProfitMetric").textContent = formatRub(model.grossProfit);
  document.querySelector("#operatingExpenseMetric").textContent = formatRub(model.operatingExpenses);
  document.querySelector("#ebitdaMetric").textContent = formatRub(model.ebitda);
  document.querySelector("#grossProfitNote").textContent = `${grossMargin}% от выручки`;
  document.querySelector("#ebitdaNote").textContent = `${ebitdaMargin}% маржа`;
}

function renderCashflow() {
  const operations = getOperations();
  const balance = operations.reduce((sum, row) => sum + row.amount, 0);
  const markup = operations
    .slice()
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 8)
    .map(
      (item) => `
        <div class="timeline-item">
          <span class="timeline-date">${item.date}</span>
          <div>
            <strong>${item.category} · ${item.market}</strong>
            <span>${item.sku}</span>
          </div>
          <span class="timeline-amount ${item.amount > 0 ? "good" : "bad"}">${formatRub(item.amount)}</span>
        </div>
      `
    )
    .join("");
  document.querySelector("#cashflowTimeline").innerHTML = markup;
  document.querySelector("#paymentModalTimeline").innerHTML = markup;
  document.querySelector("#cashAvailableMetric").textContent = formatRub(balance);
  document.querySelector("#cashAvailableMetric").className = balance >= 0 ? "good" : "bad";
  document.querySelector("#cashStatusNote").textContent = balance >= 0 ? "Разрыва не ожидается" : "Есть риск кассового разрыва";
  document.querySelector("#cashStatusNote").className = balance >= 0 ? "good" : "bad";
}

function renderMarketCards(market, target) {
  const rows = getSkuAnalytics().filter((product) => product.market === market);
  document.querySelector(target).innerHTML = rows
    .map(
      (product) => `
        <article class="market-card">
          <h3>${product.name}</h3>
          <dl>
            <div><dt>Выручка</dt><dd>${formatRub(product.revenue)}</dd></div>
            <div><dt>Прибыль</dt><dd>${formatRub(product.profit)}</dd></div>
            <div><dt>Расходы</dt><dd>${formatRub(product.costs)}</dd></div>
            <div><dt>Маржа</dt><dd>${product.margin}%</dd></div>
          </dl>
          <span class="tag ${product.margin < 14 ? "danger" : product.status.includes("Контроль") ? "warning" : ""}">${product.status}</span>
        </article>
      `
    )
    .join("");
}

function renderAds() {
  document.querySelector("#adsTable").innerHTML = ads
    .map(
      (campaign) => `
        <tr>
          <td><strong>${campaign.name}</strong></td>
          <td>${campaign.market}</td>
          <td>${formatRub(campaign.spend)}</td>
          <td>${formatRub(campaign.sales)}</td>
          <td>${campaign.drr}%</td>
          <td><span class="tag ${campaign.status === "Контроль" ? "warning" : ""}">${campaign.status}</span></td>
        </tr>
      `
    )
    .join("");
}

function renderStock() {
  const markup = stock
    .map(
      (item) => `
        <article class="stock-card">
          <h3>${item.name}</h3>
          <span class="stock-days ${item.days <= 12 ? "low" : ""}">${item.days} дней остатка</span>
          <dl>
            <div><dt>Площадка</dt><dd>${item.market}</dd></div>
            <div><dt>На складе</dt><dd>${item.quantity} шт.</dd></div>
            <div><dt>Действие</dt><dd>${item.supply}</dd></div>
          </dl>
        </article>
      `
    )
    .join("");
  document.querySelector("#stockCards").innerHTML = markup;
  document.querySelector("#supplyModalCards").innerHTML = stock
    .filter((item) => item.days <= 12)
    .map(
      (item) => `
        <article class="stock-card">
          <h3>${item.name}</h3>
          <span class="stock-days low">${item.days} дней остатка</span>
          <dl>
            <div><dt>Площадка</dt><dd>${item.market}</dd></div>
            <div><dt>Рекомендация</dt><dd>${item.supply}</dd></div>
          </dl>
        </article>
      `
    )
    .join("");
}

function renderProductFullTable() {
  const rows = getSkuAnalytics();
  const profitable = rows.filter((row) => row.profit > 0).length;
  const loss = rows.filter((row) => row.profit < 0).length;
  const avgMargin = rows.length ? Math.round((rows.reduce((sum, row) => sum + row.margin, 0) / rows.length) * 10) / 10 : 0;

  document.querySelector("#profitableSkuMetric").textContent = profitable;
  document.querySelector("#lossSkuMetric").textContent = loss;
  document.querySelector("#avgSkuMarginMetric").textContent = `${avgMargin}%`;

  document.querySelector("#productFullTable").innerHTML = rows
    .map((product) => {
      const statusClass =
        product.margin < 14 ? "danger" : product.status.includes("Проверить") || product.status.includes("Контроль") ? "warning" : "";
      return `
        <tr>
          <td><strong>${product.name}</strong></td>
          <td>${product.market}</td>
          <td>${formatRub(product.revenue)}</td>
          <td>${formatRub(product.profit)}</td>
          <td>${formatRub(product.costs)}</td>
          <td>${product.margin}%</td>
          <td><span class="tag ${statusClass}">${product.status}</span></td>
        </tr>
      `;
    })
    .join("");
}

function renderOperations() {
  const operations = getOperations().filter((row) => {
    const matchesMarket = state.operationMarket === "all" || row.market === state.operationMarket;
    const matchesType = state.operationType === "all" || row.type === state.operationType;
    const matchesSearch = !state.operationSearch || row.sku.toLowerCase().includes(state.operationSearch.toLowerCase());
    return matchesMarket && matchesType && matchesSearch;
  });
  const allOperations = getOperations();
  const income = operations.filter((row) => row.amount > 0).reduce((sum, row) => sum + row.amount, 0);
  const expense = operations.filter((row) => row.amount < 0).reduce((sum, row) => sum + Math.abs(row.amount), 0);
  const balance = income - expense;

  document.querySelector("#operationIncome").textContent = formatRub(income);
  document.querySelector("#operationExpense").textContent = formatRub(expense);
  document.querySelector("#operationBalance").textContent = formatRub(balance);
  document.querySelector("#operationBalance").className = balance >= 0 ? "good" : "bad";
  document.querySelector("#operationBalanceTone").className = balance >= 0 ? "good" : "bad";
  document.querySelector("#operationsCount").textContent = allOperations.length;

  document.querySelector("#operationsTable").innerHTML = operations
    .slice()
    .sort((a, b) => b.date.localeCompare(a.date))
    .map(
      (row) => `
        <tr>
          <td>${row.date}</td>
          <td>${row.market}</td>
          <td>${row.category}</td>
          <td>${row.sku}</td>
          <td class="${row.amount >= 0 ? "good" : "bad"}">${formatRub(row.amount)}</td>
          <td><span class="tag ${row.amount < 0 ? "warning" : ""}">${row.type === "income" ? "Приход" : "Расход"}</span></td>
        </tr>
      `
    )
    .join("");
}

function setActivePage() {
  const route = window.location.hash.replace("#", "") || "dashboard";
  const page = document.querySelector(`[data-page="${route}"]`) ? route : "dashboard";

  document.querySelectorAll(".page").forEach((element) => {
    element.classList.toggle("active", element.dataset.page === page);
  });

  document.querySelectorAll(".nav-item, .rail-item").forEach((link) => {
    link.classList.toggle("active", link.getAttribute("href") === `#${page}`);
  });
}

function renderSettings() {
  const settings = getSettings();
  document.querySelector("#wbToken").value = settings.wbToken || "";
  document.querySelector("#ozonToken").value = settings.ozonToken || "";
  document.querySelector("#erpToken").value = settings.erpToken || "";
  document.querySelector("#returnsRule").checked = settings.returnsRule ?? true;
  document.querySelector("#adsRule").checked = settings.adsRule ?? true;
  document.querySelector("#stockRule").checked = settings.stockRule ?? true;

  const connected = [
    ["WB", Boolean(settings.wbToken)],
    ["Ozon", Boolean(settings.ozonToken)],
    ["ERP", Boolean(settings.erpToken)]
  ];
  document.querySelector("#settingsSummary").innerHTML = connected
    .map(
      ([name, status]) => `
        <div class="summary-line">
          <span>${name}</span>
          <strong class="${status ? "good" : "warn"}">${status ? "Подключено" : "Нужен токен"}</strong>
        </div>
      `
    )
    .join("");
}

function csvEscape(value) {
  const text = String(value).replaceAll('"', '""');
  return `"${text}"`;
}

function downloadCsv(filename, rows) {
  const csv = rows.map((row) => row.map(csvEscape).join(";")).join("\n");
  const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function exportPnlCsv() {
  const model = getPnlModel();
  downloadCsv("sallerfix-pnl.csv", [
    ["Статья", "Сумма"],
    ...model.rows.map((row) => [row.label, row.value])
  ]);
}

function exportProductsCsv() {
  const rows = getSkuAnalytics();
  downloadCsv("sallerfix-sku.csv", [
    ["Товар", "Площадка", "Выручка", "Прибыль", "Расходы", "Маржа", "Статус"],
    ...rows.map((product) => [product.name, product.market, product.revenue, product.profit, product.costs, product.margin, product.status])
  ]);
}

function exportOperationsCsv() {
  downloadCsv("sallerfix-operations.csv", [
    ["Дата", "Площадка", "Статья", "SKU", "Сумма", "Тип"],
    ...getOperations().map((row) => [row.date, row.market, row.category, row.sku, row.amount, row.type])
  ]);
}

function parseOperationsCsv(csv) {
  return csv
    .split("\n")
    .map((row) => row.trim())
    .filter(Boolean)
    .slice(1)
    .map((row) => {
      const [date, market, category, sku, amount, type] = row.split(";").map((cell) => cell.trim());
      return {
        date,
        market,
        category,
        sku,
        amount: Number(amount.replace(",", ".")),
        type: type || (Number(amount) >= 0 ? "income" : "expense")
      };
    })
    .filter((row) => row.date && row.market && row.category && Number.isFinite(row.amount));
}

function openModal(id) {
  state.activeModal = id;
  document.querySelector("#modalBackdrop").classList.add("active");
  document.querySelector("#modalBackdrop").setAttribute("aria-hidden", "false");
  document.querySelectorAll(".modal").forEach((modal) => modal.classList.toggle("active", modal.id === id));
}

function closeModal() {
  state.activeModal = null;
  document.querySelector("#modalBackdrop").classList.remove("active");
  document.querySelector("#modalBackdrop").setAttribute("aria-hidden", "true");
  document.querySelectorAll(".modal").forEach((modal) => modal.classList.remove("active"));
}

function render() {
  const rows = getFilteredProducts();
  renderMetrics(rows);
  renderChart();
  renderProducts(rows);
  renderAlerts();
  renderExpenses();
  renderPnl();
  renderCashflow();
  renderMarketCards("WB", "#wbCards");
  renderMarketCards("Ozon", "#ozonCards");
  renderAds();
  renderStock();
  renderProductFullTable();
  renderOperations();
  renderSettings();
  setActivePage();
}

document.querySelector("#periodFilter").addEventListener("change", (event) => {
  state.period = event.target.value;
  render();
});

document.querySelector("#marketFilter").addEventListener("change", (event) => {
  state.market = event.target.value;
  render();
});

document.querySelector("#groupFilter").addEventListener("change", (event) => {
  state.group = event.target.value;
  render();
});

document.querySelector("#operationMarketFilter").addEventListener("change", (event) => {
  state.operationMarket = event.target.value;
  renderOperations();
});

document.querySelector("#operationTypeFilter").addEventListener("change", (event) => {
  state.operationType = event.target.value;
  renderOperations();
});

document.querySelector("#operationSearch").addEventListener("input", (event) => {
  state.operationSearch = event.target.value;
  renderOperations();
});

document.querySelector("#refreshButton").addEventListener("click", () => {
  const button = document.querySelector("#refreshButton");
  button.textContent = "Обновлено";
  render();
  window.setTimeout(() => {
    button.textContent = "Обновить";
  }, 1200);
});

document.querySelector("#exportPnlTop").addEventListener("click", exportPnlCsv);
document.querySelector("#exportPnlPage").addEventListener("click", exportPnlCsv);
document.querySelector("#exportSkuCompact").addEventListener("click", exportProductsCsv);
document.querySelector("#exportOperations").addEventListener("click", exportOperationsCsv);
document.querySelector("#reconcileAds").addEventListener("click", () => {
  window.location.hash = "ads";
  document.querySelector("#reconcileAds").textContent = "Сверено";
  window.setTimeout(() => {
    document.querySelector("#reconcileAds").textContent = "Сверить расходы";
  }, 1200);
});

document.querySelector("#saveSettings").addEventListener("click", () => {
  saveSettingsToStorage({
    wbToken: document.querySelector("#wbToken").value.trim(),
    ozonToken: document.querySelector("#ozonToken").value.trim(),
    erpToken: document.querySelector("#erpToken").value.trim(),
    returnsRule: document.querySelector("#returnsRule").checked,
    adsRule: document.querySelector("#adsRule").checked,
    stockRule: document.querySelector("#stockRule").checked
  });
  document.querySelector("#saveSettings").textContent = "Сохранено";
  renderSettings();
  window.setTimeout(() => {
    document.querySelector("#saveSettings").textContent = "Сохранить";
  }, 1200);
});

document.querySelector("#settingsForm").addEventListener("submit", (event) => {
  event.preventDefault();
  document.querySelector("#saveSettings").click();
});

document.querySelectorAll("[data-modal-open]").forEach((button) => {
  button.addEventListener("click", () => openModal(button.dataset.modalOpen));
});

document.querySelectorAll("[data-modal-close]").forEach((button) => {
  button.addEventListener("click", closeModal);
});

document.querySelector("#modalBackdrop").addEventListener("click", (event) => {
  if (event.target.id === "modalBackdrop") closeModal();
});

document.querySelector("#expenseForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  expenses = [
    ...expenses,
    {
      name: form.get("name").toString(),
      amount: Number(form.get("amount")),
      value: Number(form.get("value"))
    }
  ];
  event.currentTarget.reset();
  closeModal();
  renderExpenses();
});

document.querySelector("#costForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  state.costImportRows = form
    .get("csv")
    .toString()
    .split("\n")
    .map((row) => row.trim())
    .filter(Boolean).length;
  closeModal();
  const button = document.querySelector("[data-modal-open='costModal']");
  button.textContent = `Импортировано: ${Math.max(0, state.costImportRows - 1)} строк`;
});

document.querySelector("#operationImportForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const imported = parseOperationsCsv(form.get("csv").toString());
  if (imported.length) {
    saveOperations([...getOperations(), ...imported]);
    render();
  }
  event.currentTarget.reset();
  closeModal();
});

window.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && state.activeModal) closeModal();
});

window.addEventListener("hashchange", setActivePage);

render();
